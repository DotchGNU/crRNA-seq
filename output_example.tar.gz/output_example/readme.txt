# get input example
wget http://ago.korea.ac.kr/crispr_abasic/crRNA_sequencing_SF370/SF370_1a.R1.fastq.gz

# run script
bash main.sh
